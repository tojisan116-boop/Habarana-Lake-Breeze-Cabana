# Habarana Lake Breeze Cabana — Website

A responsive static website design for Habarana Lake Breeze Cabana.

## Files

- `index.html` — main website
- `style.css` — design and responsive layout
- `script.js` — mobile navigation + current year
- `assets/logo.jpg` — supplied logo/brand image
- `assets/activities.jpg` — supplied activities poster

## Publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload every file and the `assets` folder.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`.
6. Save and wait for GitHub Pages to publish.

## Important content note

The website uses information found in the current Booking.com listing and public business data. Confirm prices, room inventory, activity prices, policies, phone number, and exact activity arrangements directly with the property before publishing them as final business information.

The site intentionally does not invent guest reviews.
